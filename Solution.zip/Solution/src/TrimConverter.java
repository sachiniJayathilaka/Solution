public class TrimConverter implements ConverterInterface{
    @Override
    public String convert(String text) {
        StringBuilder result = new StringBuilder();

        // Find title and description tags and extract their content
        String title = extractContent(text, "title");
        String description = extractContent(text, "description");

        // Append the extracted content to the result
        if (title != null) {
            result.append(title).append("\n");
        }
        if (description != null) {
            result.append(description);
        }

        return result.toString();
    }

    private String extractContent(String text, String tag) {
        int startIndex = text.indexOf("<" + tag + ">");
        int endIndex = text.indexOf("</" + tag + ">", startIndex);
        if (startIndex != -1 && endIndex != -1) {
            return text.substring(startIndex + tag.length() + 2, endIndex);
        }

        return null;
    }
}
