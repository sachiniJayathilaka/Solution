import java.io.IOException;

public interface OutputInterface {
    void output(String data) throws IOException;
}
