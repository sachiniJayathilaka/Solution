import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

class FileOutput implements OutputInterface {
    private final String filePath;

    public FileOutput(String filePath) {
        this.filePath = filePath;
    }

    @Override
    public void output(String data) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(data);
            System.out.println("Output written to file: " + filePath);
        }
    }
}
