import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileInput implements InputInterface {
    @Override
    public String getInput(String source) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(source));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line).append("\n");
        }
        return stringBuilder.toString();
    }
}
