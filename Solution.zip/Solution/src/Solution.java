import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Solution {

    public static void main(String[] args) {

        // validate input arguments and command should be start --input
        if (args.length == 0 && !args[0].startsWith("--input=")) {
            System.out.println("Please enter valid arguments");
            return;
        }

        Map<String, String> params = new HashMap<>();
        for (String arg : args) {
            String[] parts = arg.split("=", 2);
            if (parts.length == 2) {
                params.put(parts[0], parts[1]);
            }
        }

        try {
            InputInterface inputInterface;
            String inputData;
            if (params.get("--input").startsWith("http")) {
                inputInterface = new URLInput();
                inputData = inputInterface.getInput(params.get("--input"));
            } else {
                String source = args[0].substring("--input=".length());
                inputInterface = new FileInput();
                inputData = inputInterface.getInput(source);
            }

            String convertedData = inputData; // Default to original data
            if (params.containsKey("--convert")) {
                ConverterInterface converterInterface = new TrimConverter();
                 convertedData = converterInterface.convert(inputData);
            }

            if (params.containsKey("--replace")) {
                String[] replaceParams = params.get("--replace").split(",");
                ConverterInterface converterInterface = new ReplaceConverter(replaceParams[0], replaceParams[1]);
                convertedData = converterInterface.convert(convertedData);
            }

            OutputInterface outputInterface;
            if (params.containsKey("--output")) {
                outputInterface = new FileOutput(params.get("--output"));
            } else {
                outputInterface = new StandardOutput();
            }
            outputInterface.output(convertedData);

        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }
}