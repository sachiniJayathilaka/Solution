public class StandardOutput implements OutputInterface {
    @Override
    public void output(String data) {
        System.out.println(data);
    }
}