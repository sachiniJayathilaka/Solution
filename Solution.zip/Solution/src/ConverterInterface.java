public interface ConverterInterface {
    String convert(String text);
}
