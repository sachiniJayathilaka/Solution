import java.io.IOException;

public interface InputInterface {
    String getInput(String source) throws IOException;
}
