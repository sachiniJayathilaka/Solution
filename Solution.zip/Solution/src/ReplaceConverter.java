public class ReplaceConverter implements ConverterInterface {
    private final String from;
    private final String to;

    public ReplaceConverter(String from, String to) {
        this.from = from;
        this.to = to;
    }

    @Override
    public String convert(String text) {

        return text.replaceAll(from, to);
    }
}
